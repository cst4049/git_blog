import json
from bson import ObjectId
from datetime import date, datetime

from flask import jsonify


class JSONEncoder(json.JSONEncoder):

    def default(self, o):

        if isinstance(o, ObjectId):
            return str(o)
        if isinstance(o, datetime):
            return o.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(o, date):
            return o.strftime('%Y-%m-%d')
        return json.JSONEncoder.default(self, o)

def recursion_structuring(_id ,list,mongoDB_collection):
    """
    用递归的方式 把ID对应的botn节点本身和他所有的后代都返回到一个list里
    :param _id:
    :param list:
    :param mongoDB_collection:
    :return:
    """
    node = mongoDB_collection.find_one({'_id':ObjectId(_id)})
    if type(node) != None:
        if 'son' in node.keys():
            for son_item in node['son']:
                recursion_structuring(son_item, list, mongoDB_collection)
        list.append(node)
    pass

def objectIds_convert_json(obj):
    return jsonify(json.loads(my_dump(obj),encoding="UTF-8"))


def my_dump(d):
    """
    将对象里的 所有ObjectId 都转化为 str
    来源: https://stackoverflow.com/questions/16586180/typeerror-objectid-is-not-json-serializable
    :param d:
    :return:
    """
    return JSONEncoder().encode(d)

def pre_insert(resource,req):
    pass


def burnavi(Q,R,M,Lyro,Lyri):
    pass


def allXxxLyro(resource, request, lookup):
    pass


def allXxxLyroTop(resource, request, lookup):
    pass


def allXxxLyroJust(resource, request, lookup):
    pass


def among(t,b):
    pass


