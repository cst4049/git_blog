
##### 2017-10-24
现在流程

1. excel--> yaml格式(已经完成)
2. 运行 yaml_convertTO_json脚本(已经完成, 将所有yaml 转成json 并分类保存)
3. 执行 postman 脚本(未完成)
