from flask import current_app as app, request, jsonify
from model.Users import Users

def change_passwd(user_id):
    '''
    修改Users的密码,只能通过patch提交
    :param user_id:
    :return:
    '''

    passwd = request.json.get("passwd")

    user_ins =  Users.find_one_obj(user_id)

    if user_ins == None :

        return jsonify({"errorMsg": "账号不存在."})
    else :
        return jsonify({"msg":"修改成功"})

