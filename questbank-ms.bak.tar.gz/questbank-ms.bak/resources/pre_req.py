import time
from flask import current_app as app
from flask import request

from eve.methods.common import oplog_push

def delay():
    delay = app.config.get('DEBUG_DELAY')
    time.sleep(delay)


def record():
    lookup = {}
    lookup.update(
        record_time = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()),
        method = request.method,
        data = request.json or request.args or request.form,
        url = request.url
    )
    if lookup.get('method') != 'GET':
        log = app.data.driver.db['log']
        log.insert(lookup)
