from model.Question import Question
from bson import ObjectId
from flask import request
from hooks.auxiliary import getczj_info,getcombo_info
from flask import jsonify


def moveto(para):
    question,name,d = para
    id = d.get('_id')
    if 'botn' in d:
        botn = d.get('botn')
        toinfo = getczj_info(botn)
    elif 'comboFormat' in d:
        combo = d.get('comboFormat')
        toinfo = getcombo_info(combo)
    else:
        raise ValueError

    lookup = {'quesBank':name,'_id':ObjectId(id)}
    data = question.find_one(lookup)

    res = {
        '_id':id
    }

    if not data or not toinfo:
        res.update(info = 'parame may not correct')
        return res

    if toinfo.get('koLyro') in data:
        upinfo = question.update_one(lookup,{'$set':{toinfo.get('koLyro'):botn}})
        status = 'move success' if upinfo.raw_result.get('ok') else 'move fail'
    elif 'comboFormat' in data:
        upinfo = question.update_one(lookup,{'$set':{'comboFormat':toinfo.get('responseFormat')}})
        status = 'move success' if upinfo.raw_result.get('ok') else 'move fail'
    else:
        status = 'please check your parameter'
    res.update(info = status)
    return res


def move(name):
    '''批量移动'''
    question = Question.coll()
    args = request.json
    if isinstance(args,list):
        para = [(question,name,d) for d in args]
        data = list(map(moveto, para))
    if isinstance(args,dict):
        para = (question,name,args)
        data = moveto(para)
    resp = jsonify(data)
    return resp