from flask import current_app as app
from model.BurTree import BurTreeNode;


class Enum:


    @staticmethod
    def coll():
        col = app.data.driver.db['enum']
        return col
