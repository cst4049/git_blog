from flask import current_app as app
from hooks.req_addon import *
from model.BOT import BOTNode
import datetime


class Question:

    # 题目相关
    @staticmethod
    def coll():
        col = app.data.driver.db['question']
        return col

    @staticmethod
    def get_discipline():
        discipline = ''
        return discipline

    @staticmethod
    def get_checkStatus():
        checkStatus = ''
        return checkStatus

    @staticmethod
    def isChecked():
        checkStatus = ''
        return checkStatus
    pass

    @staticmethod
    def parsearg(request,lookup,botn=None):
        '''
        参数解析，英语非英语
        :param request:
        :param lookup:
        :param botn:
        :return:
        '''
        scope = json.loads(request.args.get('scope'))
        if scope:  # scope 控制范围,如果没有这个参数默认查询name题库下所有
            lookup.update(scope)
            lyro = []
            if 'botn' in scope:
                botnid = scope.get('botn')
                recursion_structuring(botnid, lyro, botn)
                if scope.get('koDiscipline') == 'english':
                    vid = [i.get('_id') for i in lyro if i.get('koLyro') == 'volume']
                    lookup.update({"$or": [{"volume": {"$in": vid}}]})
                else:
                    sid = [i.get('_id') for i in lyro if i.get('koLyro') == 'section']
                    lookup.update({"$or": [{"section": {"$in": sid}}]})
                lookup.pop('botn')
        return lookup

    def do_statis(iterlist):
        '''
        分组,按照指定的字段分组列表
        :return:
        '''
        d = {}
        for k,v in iterlist:
            l = []
            for val in v:
               l.append(val)
            d.update({k:l})
        return d


    def get_userlist(entered,taged,checked):
        '''
        获取三种信息的所有用户,去除重复
        :param taged:
        :param checked:
        :return:
        '''
        alist = []
        _no = [alist.extend(list(i)) for i in [entered,taged,checked]]
        ulist = set(alist)
        userL = []
        for uid in ulist:
            if uid in entered:
                if entered.get(uid):
                    user = entered.get(uid)[0].get('enteredman')[0]
            elif uid in taged:
                if taged.get(uid):
                    user = taged.get(uid)[0].get('tagedman')[0]
            elif uid in checked:
                if checked.get(uid):
                    user = checked.get(uid)[0].get('checkedman')[0]
            else:
                raise ValueError
            userL.append(user)
        return userL

    @staticmethod
    def get_stat(question, lookup, discipline, role, start, to):
        '''
        获取状态信息
        :param question:
        :param lookup:
        :param discipline:
        :param role:
        :param start:
        :param to:
        :return:
        '''
        #db.question.aggregate({"$match": {"_id": ObjectId("59e6bb970b4b4b255db46a69")}}, {
        #    "$lookup": {"localField": "tagedBy", "from": "users", "foreignField": "_id", "as": "tagedBy"}})
        # if discipline:
        #     lookup.update(koDiscipline=discipline)
        #if role:  # 内嵌文档的查询
        #    lookup.update(role=role)
        if start and not to:
            start = datetime.datetime.strptime(start,'%Y-%m-%d')
            lookup.update({'_created':{'$gte':start}})
        if to and not start:
            to = datetime.datetime.strptime(to, '%Y-%m-%d')
            lookup.update({'_created':{'$lte':to}})
        if start and to:
            start = datetime.datetime.strptime(start, '%Y-%m-%d')
            to = datetime.datetime.strptime(to, '%Y-%m-%d')
            lookup.update({'$and': [{'_created':{'$gte':start}},{'_created':{'$lte':to}}]})

        project = {'_created':0,"_id":0,"_updated":0,"_version":0,
                   'enteredman._created':0,"enteredman._updated":0,"enteredman._version":0,"enteredman.passwd":0,
                   'tagedman._created':0,"tagedman._updated":0,"tagedman._version":0,"tagedman.passwd":0,
                   'checkedman._created':0,"checkedman._updated":0,"checkedman._version":0,"checkedman.passwd":0
                   }

        _lookup = [
            {"$match": lookup},
            {"$lookup": {"localField": "enteredBy", "from": "users", "foreignField": "_id", "as": "enteredman"}},
            {"$lookup": {"localField": "tagedBy", "from": "users", "foreignField": "_id", "as": "tagedman"}},
            {"$lookup": {"localField": "checkedBy", "from": "users", "foreignField": "_id", "as": "checkedman"}},
            # {"$match":{"$or":[{"enteredman.primaryRole":role},{"tagedman.primaryRole":role},{"checkedman.primaryRole":role}]} if role else {}},
            {"$project": project}
        ]

        data = list(question.aggregate(_lookup))  #获取所有的数据

        data_entered = (i for i in data if 'enteredBy' in i)
        entered = groupby(data_entered,itemgetter('enteredBy'))

        data_taged = (i for i in data if 'tagedBy' in i)
        taged = groupby(data_taged,itemgetter('tagedBy'))

        data_checked = (i for i in data if 'checkedBy' in i)
        checked = groupby(data_checked,itemgetter('checkedBy'))

        info_entered = Question.do_statis(entered)
        info_taged = Question.do_statis(taged)
        info_checked =Question.do_statis(checked)

        userlist = Question.get_userlist(info_entered,info_taged,info_checked)
        static = []
        for user in userlist:
            if not role or user.get('primaryRole') == role and not discipline or user.get('primaryDiscipline') == discipline:
                user_for_enter = [ques for ques in (i for i in data if 'enteredBy' in i)
                                  if ques.get('enteredBy') == user.get('_id')]
                user_for_tag = [ques for ques in (i for i in data if 'tagedBy' in i)
                                if ques.get('tagedBy') == user.get('_id')]
                user_for_check = [ques for ques in (i for i in data if 'checkedBy' in i)
                                  if ques.get('checkedBy') == user.get('_id')]
                # if user_for_enter: # 时间排序
                #     start_time = min(user_for_enter,key=lambda s:s['_created'])
                #     end_time = max(user_for_enter,key=lambda s:s['_created'])
                if user.get('primaryDiscipline') == 'english':
                    comboFormat = set([i.get('comboFormat') for i in user_for_enter]) | \
                                  set([i.get('comboFormat') for i in user_for_tag]) | \
                                  set([i.get('comboFormat') for i in user_for_check])
                    dist = list(comboFormat)
                    distribution = {'comboFormat':dist.remove(None) if None in dist else dist}

                else:
                    section = set([i.get('section') for i in user_for_enter]) | \
                                  set([i.get('section') for i in user_for_tag]) | \
                                  set([i.get('section') for i in user_for_check])
                    section = list(section)
                    if section:
                        botn = BOTNode.coll()
                        botn_chapter = list(botn.find({'_id':{'$in':section}},{'_id':0}))
                        chapter = set(i.get('dad') for i in botn_chapter)
                        dist = list(chapter)
                        distribution = {'chapter': dist.remove(None) if None in dist else dist}
                        distribution.update({"section":section.remove(None) if None in section else section})
                    else:
                        dist = {}
                static.append({
                    "user": user,
                    "entered": len(user_for_enter),
                    "taged": len(user_for_tag),
                    "checked": len(user_for_check),
                    "distribution": distribution
                })

        return static

