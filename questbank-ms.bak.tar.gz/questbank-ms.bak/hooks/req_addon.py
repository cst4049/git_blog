from flask import current_app as app
from unit import *
from .auxiliary import parse_quesarg
from flask import abort


def pre_GET(resource, request, lookup):
    if resource == 'question':
        data = parse_quesarg(request,lookup)
        if not data:
            pass
        elif len(data) == 1:
            abort(data)
        else:
            request.args,lookup = data


def pre_PATCH(resource, request, lookup):
    pass


def pre_PUT(resource, request, lookup):
    pass

def pre_POST(resource, request):
    # if resource == 'tag':
    #     question = app.data.driver.db['question']
    #     lookup = ObjectId(request.view_args.get('_id'))
    #     aa = question.update_one({'_id':lookup},{'$set':{"contOfQuery":"eeeeeeeeeeeaaaabbbb"}})
    #     exit() todo
    if resource == "question":
        if request.json.get("koDiscipline") == "english" and "section" in request.json:
            request.json.pop("section")
            #request.data = str(request.json).encode("utf-8")
    pass


def pre_DELETE(resource, request, lookup):
    pass


def post_GET(resource, request, lookup):
    pass

    return
    # if resource == "botn-sonern" and lookup._status_code == 200:
    #     #根据 id去查对应  botn
    #     #pop出 son  , for循环 查DB  查询条件  dad= 这个ID
    #     base_url_str = request.base_url
    #     _id =  re.search('[a-f0-9A-F]{24}',base_url_str).group()
    #     botnCollection = app.data.driver.db["botn"]
    #     sons = botnCollection.find({'dad':ObjectId(_id)})
    #     list =[]
    #     for son_item in sons:
    #         list.append(json.loads(my_dump(son_item)))
    #
    #
    #     #组装返回结果
    #     resp = json.loads(lookup.response[0].decode('utf-8'))
    #     resp.update(_items=list)
    #     resp['_meta']['total'] = len(list)
    #
    #
    #     lookup.response[0] = json.dumps(resp).encode('utf-8')
    #     lookup.content_length = len(json.dumps(resp).encode('utf-8'))
    #
    # if resource == 'botn-sonward' and lookup._status_code == 200:
    #     """
    #     外层通上, 内层获取 list使用递归
    #     """
    #     base_url_str = request.base_url
    #     _id = re.search('[a-f0-9A-F]{24}',base_url_str).group()
    #
    #     botnCollection = app.data.driver.db['botn']
    #     list=[]
    #     recursion_structuring(_id,list,botnCollection )
    #     list_new=[]
    #     for i in list:
    #         dict_item = {}
    #         for k ,v in i.items():
    #             dict_item[k]=v.__str__()
    #         list_new.append(dict_item)
    #     list= list_new
    #
    #     resp = json.loads(lookup.response[0].decode('utf-8'))
    #     resp.update(_items=list)
    #     resp['_meta']['total'] = len(list)
    #     lookup.response[0] = json.dumps(resp).encode('utf-8')
    #     lookup.content_length = len(json.dumps(resp).encode('utf-8'))
    #     pass



def post_PATCH(resource, request, lookup):
    pass


def post_PUT(resource, request, lookup):
    pass


def post_POST(resource, request,lookup):
    if resource == 'pictures' and lookup._status_code == 201:
        resp = json.loads(lookup.response[0].decode('utf-8'))
        _id = resp.get("_id")
        picture = app.data.driver.db["pictures"]
        look_up = {'_id':ObjectId(_id)}
        respdata = picture.find_one(look_up)
        imgfileid = respdata.get("upload")
        if len(imgfileid) == 1:
            url = request.url_root + app.config.get("MEDIA_ENDPOINT") +'/'+ str(imgfileid[0])
        else:
            url = [ request.url_root + app.config.get("MEDIA_ENDPOINT")+'/'+ str(imgid) for imgid in imgfileid ]
        resp['url'] = url
        resp['uploaded'] = 1
        resp['fileName'] = respdata.get("filename")
        resp = json.dumps(resp).encode('utf-8')
        lookup.response[0] = resp
        lookup.content_length = len(resp)


    if resource=='bott' and lookup._status_code == 201:
        resp = json.loads(lookup.data.decode('utf-8'))
        _id = resp["_id"]
        bottCollection = app.data.driver.db["bott"]
        botTree = bottCollection.find_one({'_id':ObjectId(_id)})
        #获取root 节点
        rootNode = botTree.pop('root')
        rootNode.update(dad=ObjectId(_id))
        # 将教材的版本传入
        rootNode.update(edition=botTree['edition'])


        #root树 扁平化
        list = []
        flatten_burtree_by_recursion(rootNode,list)
        #插入botn中
        botnCollection = app.data.driver.db['botn']
        print("list",list)
        botnCollection.insert(list)
        #root节点保存 root对应的objectId
        bottCollection.update({'_id': ObjectId(_id)}, {'$set':{"root": list[-1]['_id']}})
        pass

    """
    0.已经把树存到db中
    1.找到该节点,获取root的值
    2.将版本号传入root节点里
    3.*调用 扁平化方法.返回一个list*
    4.将list存入bokn中
    5.把树替换成对应的id
    """
    if resource == "bokt" and lookup._status_code == 201:
        resp = json.loads(lookup.data.decode('utf-8'))
        _id = resp["_id"]
        boktCollection = app.data.driver.db["bokt"]
        bokTree = boktCollection.find_one({'_id':ObjectId(_id)})
        #获取root 节点
        rootNode = bokTree.pop('root')
        rootNode.update(dad=ObjectId(_id))
        # 将教材的版本传入
        rootNode.update(edition=bokTree['edition'])


        #root树 扁平化
        list = []
        flatten_burtree_by_recursion(rootNode,list)
        #插入botn中
        boknCollection = app.data.driver.db['bokn']
        print("list",list)
        boknCollection.insert(list)
        #root节点保存 root对应的objectId
        boktCollection.update({'_id': ObjectId(_id)}, {'$set':{"root": list[-1]['_id']}})
        pass

def flatten_burtree_by_recursion(items, list):
    """
    将传入bokt 扁平化, 将其转为一个一个的节点存入数组
    author: 琛
    :param items:
    :param list:
    :return 返回一个数组 该数组包含bokt的所有节点:
    """
    if type(items) == type({}):
            item_sub = items

            if "son" in item_sub:
                subs = item_sub.pop("son")
                if type(subs) != type(None):

                    #为册添加科目名
                    if item_sub['koLyro'] == 'discipline':
                        for son_item in subs:
                            son_item.update(discipline=item_sub['name'])
                    index = []
                    #如果存在objectId 则使用. 否则生成一个作为_id
                    if "_id" not in item_sub:
                        origin_id = ObjectId()
                        item_sub.update(_id=origin_id)
                    else:
                        origin_id  = item_sub['_id']

                    #给子类添加 父_id 并把子类_id 存在父_id的son数组里
                    for sub in subs:
                        _id = ObjectId()
                        index.append(_id)
                        sub.update(_id=_id, dad=origin_id)
                        sub.update(edition=item_sub['edition'])
                        item_sub.update(son=index)

                    for item in subs:
                        flatten_burtree_by_recursion(item, list)
            list.append(item_sub)

    if type(items) ==type([]):
        for item_sub in items:
            if "son" in item_sub:
                subs = item_sub.pop("son")
                if type(subs) != type(None):

                    #为册添加科目名
                    if item_sub['koLyro'] == 'discipline':
                        for son_item in subs:
                            son_item.update(discipline=item_sub['name'])
                    index = []
                    #如果存在objectId 则使用. 否则生成一个作为_id
                    if "_id" not in item_sub:
                        origin_id = ObjectId()
                        item_sub.update(_id=origin_id)
                    else:
                        origin_id  = item_sub['_id']

                    #给子类添加 父_id 并把子类_id 存在父_id的son数组里
                    for sub in subs:
                        _id = ObjectId()
                        index.append(_id)
                        sub.update(_id=_id, dad=origin_id)
                        sub.update(edition=item_sub['edition'])
                        item_sub.update(son=index)


                    for item in subs:
                        flatten_burtree_by_recursion(item, list)
            list.append(item_sub)





def post_DELETE(resource, request, lookup):

    pass
    # if resource == 'questionbank' and lookup._status_code == 204:
    #     _id = request.get("view_args").get("_id")
    #     question = app.data.driver.db["question"]
    #     picture = app.data.driver.db["picture"]
    #     look_up = {'QuestionBank':ObjectId(_id)}
    #     resp = question.update(look_up,{"$set":{"_deleted":True}},False,True)
    #     resp = picture.update(look_up, {"$set": {"_deleted": True}}, False, True)
    #
    # if resource == 'question' and lookup._status_code == 204:
    #     _id = request.get("view_args").get("Question")
    #     picture = app.data.driver.db["picture"]
    #     look_up = {'Question':ObjectId(_id)}
    #     respdata = question.update(look_up,{"$set":{"_deleted":True}},False,True)


def recursion_structuring_copy(_id ,list,mongoDB_collection):
    '''
    复制上面的recursion_structuring_copy,缺一个返回参数koLyro,后期review在合并 todo
    :param _id:
    :param list:
    :param mongoDB_collection:
    :return:
    '''
    node = mongoDB_collection.find_one({'_id':ObjectId(_id)},{'name':1,'_id':1,'dad':1,'son':1,'title':1,'koLyro':1})
    if node:
        if 'son' in node.keys():
            for son_item in node['son']:
                recursion_structuring_copy(son_item, list, mongoDB_collection)
        list.append(node)

def ques_status(id):
    mongoDB_collection = app.data.driver.db['botn']
    list = []
    recursion_structuring_copy(id,list,mongoDB_collection)
    return list
