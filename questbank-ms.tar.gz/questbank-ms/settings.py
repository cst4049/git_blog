import yaml
import os

# 默认返回xml,
XML = False

# 数据库信息




MONGO_HOST = os.environ.get('MONGO_HOST') or \
             '172.17.9.10'
MONGO_PORT = int(os.environ.get('MONGO_PORT')) if \
                    os.environ.get('MONGO_PORT') else 27017
MONGO_DBNAME = 'cb'





# Enable reads (GET), inserts (POST) and DELETE for resources/collections
# (if you omit this line, the API will default to ['GET'] and provide
# read-only access to the endpoint).
RESOURCE_METHODS = ['GET', 'POST','DELETE']

# Enable reads (GET), edits (PATCH), replacements (PUT) and deletes of
# individual items  (defaults to read-only item access).
ITEM_METHODS = ['GET', 'PATCH', 'PUT', 'DELETE']

# Enabled documents version control when True
VERSIONING = True

# oplog
OPLOG = True
OPLOG_ENDPOINT = 'oplog'

# Enables / Disables global the possibility to override
# the sent method with a header X-HTTP-METHOD-OVERRIDE.
ALLOW_OVERRIDE_HTTP_METHOD = True

# True to enable concurrency control, False otherwise. Defaults to True
IF_MATCH = False

# Controls the embedding of the media type in the endpoint response.
# This is useful when you have other means of getting the binary
# (like custom Flask endpoints) but still want clients to be able to
# POST/PATCH it. Defaults to True
RETURN_MEDIA_AS_BASE64_STRING = False

# 	Set it to True to enable serving media files at a dedicated
# media endpoint. Defaults to False.
RETURN_MEDIA_AS_URL = True

# If set to True, multiple values sent with the same key, submitted
# using the application/x-www-form-urlencoded or multipart/form-data
# content types, will
AUTO_COLLAPSE_MULTI_KEYS = True

# When submitting a non list type value for a field with type list,
# automatically create a one element list before running the validators.
# Defaults to False
AUTO_CREATE_LISTS = True

# Enables soft delete when set to True
SOFT_DELETE = True

# Hypermedia as the Engine of Application State
HATEOAS = False

# CORS (Cross-Origin Resource Sharing) support. Allows API maintainers
# to specify which domains are allowed to perform CORS requests.
# Allowed values are: None, a list of domains, or '*' for a wide-open API. Defaults to None.
X_DOMAINS = '*'

X_HEADERS = ['Content-Type']

# sleep time s/秒
DEBUG_DELAY = 0

# 重题检测默认题目数
SIMILAR_COUNT = 5

# cache
CACHE_CONTROL = 'no-cache'

DOMAIN = {}

for file in ["./schema-allinone.yaml"]:
    f = open(file)
    schemas = yaml.load(f)
    for k,v in schemas.items():
        collection = k
        info = v
        # if collection == "quesbank":
        #     info.update(additional_lookup = {
        #         'url': 'regex("[\w]+")',
        #         'field': 'name'
        #     },
        #                 id_field='name')
        #     info.update(url='quesbanks')

        # if collection == "question":
        #     info.update(url=
        #                 'quesbanks/<regex("[\w]+"):quesBank>/questions'
        #                 )

        # if collection == "picture":
        #     info.update(url=
        #                 'quesbanks/<regex("[\w]+"):quesBank>/questions/<regex("[0-9a-z]{24}"):question>/pictures'
        #                 )
        #
        # if collection == 'Enum':
        #     info.update(url='mm/enums')
        #
        #     info.update({
        #         'additional_lookup': {
        #             'url': 'regex("[\w]+")',
        #             'field': 'name'
        #         }})
        #
        # if collection == 'Literal':
        #     info.update(url='mm/enums/<regex("[\w]+"):enum>/literals')
        #     info.update({
        #         'additional_lookup': {
        #             'url': 'regex("[\w]+")',
        #             'field': 'code'
        #         }})




        # if collection == "question":
        #     aa = deepcopy(info)
        #     aa.pop('url')
        #     aa.update(url=
        #                 'quesbanks/<regex("[\w]+"):quesBank>/questions/<regex("[\w]+"):_id>/tag/'
        #                 )
        #     tag = {
        #         'item_lookup': False,
        #         'id_field': 'question',
        #         'datasource': {
        #             'source': 'question'
        #         }}
        #
        #     aa.update(tag)
        #     DOMAIN.update({"tag":aa})

        # if collection == "question":
        #     bb = deepcopy(info)
        #     bb.pop('url')
        #     bb.update(url=
        #                 'quesbanks/<regex("[\w]+"):quesBank>/questions-bot-status-stat'
        #                 )
        #     tag = {
        #         'item_lookup': False,
        #         'id_field': 'question',
        #         'datasource': {
        #             'source': 'question'
        #         }}
        #
        #     bb.update(tag)
        #     DOMAIN.update({"question_status":bb})
        #
        # if collection == "question":
        #     cc = deepcopy(info)
        #     cc.pop('url')
        #     cc.update(url=
        #                 'quesbanks/<regex("[\w]+"):quesBank>/questions-tag-status-stat'
        #                 )
        #     tag = {
        #         'item_lookup': False,
        #         'id_field': 'question',
        #         'datasource': {
        #             'source': 'question'
        #         }}
        #
        #     cc.update(tag)
        #     DOMAIN.update({"question_tag":cc})


        DOMAIN.update({collection: info})