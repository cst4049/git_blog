from flask import request
from hooks.req_addon import *
from hooks.taginfo import *
from model.BOK import BOKNode
from model.Question import Question
from model.BOT import BOTNode
from model.ENUM import Enum
from flask import make_response

from model.Vocabulary_phrase_list import Vocabulary_phrase


def question_summations(name):
    '''
    题目的统计信息
    :param id:
    :return:
    '''
    args = request.args
    scope = json.loads(args.get('scope'))

    discipline = scope.get('koDiscipline')
    botnid = scope.get('botn')

    sonward = ques_status(botnid)
    botn = getczj_info(botnid)
    if not sonward:
        return jsonify(dict(info="botn has not found"))
    questions = query_question_stat(sonward,botn,discipline)
    return jsonify({'_items':json.loads(my_dump(questions))})


def batch_question_summations(name):
    '''
    题目的统计信息,batch
    :param id:
    :return:
    '''
    args = request.args
    scope = json.loads(args.get('scope'))

    discipline = scope.get('koDiscipline')
    botnid = args.get('sonern-of')

    sonward = ques_status(botnid)
    if not sonward:
        return jsonify(dict(info="botn has not found"))
    questions = query_questions_stat(sonward,discipline)
    resp = jsonify({'_items':json.loads(my_dump(questions))})
    return resp


def botn_son(id,suffix ,structure='flatten'):
    """
    返回 botn 的子节点. 根据后缀返回 sonern or sonward
    :param id:
    :param suffix:
    :return:
    """
    botnCollection = BOTNode.coll()
    list = []

    if suffix == 'sonern':
        recursion_structuring(id, list, botnCollection)
        #因为 最后加入的是 本节点.所以直接pop最后一个就可以了.
        #如果后续加入 排序 此方法不可用
        list.pop()
    if suffix == 'sonward':
        recursion_structuring(id, list, botnCollection)

    flag_structure = request.args.get("structure")

    if flag_structure == None or flag_structure == 'flatten':
        flag_structure = structure

    if flag_structure == 'tree':
        tree = flattern_convertTo_tree(list)
        return objectIds_convert_json({"items":tree})
    return jsonify({'items': json.loads(my_dump(list))})

def bokn_son(id,suffix):
    """
    返回 bokn的子节点 , 根据后缀返回sonern or sonward
    :param id:
    :param suffix:
    :return:
    """
    boknCollection = BOKNode.coll()
    list = []
    if suffix == 'sonern':
        recursion_structuring(id,list,boknCollection)
        list.pop()

    flag_structure =request.args.get("structure")
    if flag_structure == None or flag_structure == 'flatten':
        flag_structure = 'flatten'
    if flag_structure == 'tree':
        tree = flattern_convertTo_tree(list)
        return objectIds_convert_json({"items": tree})
    return jsonify({'items': json.loads(my_dump(list))})

#找到root 节点
def flattern_convertTo_tree(list):
    """
    将 list列表 组装成树
    :param list:
    :return:
    """
    dadList=[]
    sonList =[]
    for item in list:
        if 'son' in item :
            # if sonList.count(item['son'])
            if type(item['son']) == type(list):
                for son_item in item['son']:
                    sonList.append(son_item)

        if 'dad' in item :
            dadList.append(item['dad'])

    for dad_item  in dadList:
        if dad_item not in sonList:
             root_dad_id = dad_item

    root = []
    for i in list:
        if root_dad_id == i['dad']:
            root.append(i)
    if type(root) == type([]):
        for root_item in root:
            if 'son' in root_item:
                    #调用 将该节点下所有son节点都找到的方法
                root_son_node = flattern_convertTo_tree_recursion(root_item['son'],list)
                root_item.update(son=root_son_node)
    return root

#英语知识点查询接口
"""
    获取查询条件.
    通过查询条件去找节点.
    调用递归遍历该节点的所有子节点
"""
def english_bokn_query(bok_type):

    condition = request.args["where"]
    structure = request.args['structure']
    condition =json.loads(condition)

    #查询节点 ,然后调用递归的方法.
    bok_obj = BOKNode.find_by_edition_name(bok_type,condition["edition"])

    if bok_obj == None:
        return jsonify(errorMsg="暂未找到资源,请联系zyc,添加相关资源 ^_^)~"),404


    result = []
    tree_list = []
    bokn_name =""
    for temp in bok_obj:
        result.append(temp)
        bokn_name = temp["name"]
    #返回 词法 句法
    if bokn_name in ["fill-word-in-text",
                     "simple-selection",
                     "fill-word-in-sentence",
                     "phrase-translation",
                     "sentence-translation",
                     "pattern-transformation",
                     "sentence-completion"]:
        morphology = BOKNode.find_one_by_edition_name("词法",condition["edition"])
        syntax = BOKNode.find_one_by_edition_name("句法",condition["edition"])
        temp_list = []
        recursion_structuring(morphology["_id"],temp_list,BOKNode.coll())
        morphology_list = temp_list
        temp_list = []
        recursion_structuring(syntax["_id"],temp_list,BOKNode.coll())
        syntax_list = temp_list
        tree_list.append(morphology_list)
        tree_list.append(syntax_list)
        pass

    #返回词汇和固定搭配
    if bokn_name in ["phrase-translation","sentence-translation","pattern-transformation","sentence-completion"]:
        vocabulary_list = Vocabulary_phrase.find_one_by_name("vocabulary_3000")
        phrase_list = Vocabulary_phrase.find_one_by_name("phrase_2000")
        result.append(vocabulary_list)
        result.append(phrase_list)
        pass


    # 将列表转成树
    if structure == "tree":
        for tree_item in tree_list:


            result.append(flattern_convertTo_tree(tree_item))

    return objectIds_convert_json({"msg":result})




"""
1.将obj_id 变成obj对象
2.判断obj是否有 son节点
    有. 调用自身
    否. obj 替换 obj_id ,存到数组中.
    返回
"""
def flattern_convertTo_tree_recursion(obj_id_list, node_list):
    """
    botn 列表 转换为 tree的方法.一般不直接调用. 通常调用 flattern_convertTo_tree
    :param obj_id_list:
    :param node_list:
    :return:
    """
    for id_list_index in range(len(obj_id_list )):
        #1.将其转化为 对象
        for node_item in node_list:
            if node_item['_id'] == obj_id_list[id_list_index]:
                #2. 找到该对象 判断是否有son 节点 ,有 则递归. 否 则替换list对象
                obj_id_obj = node_item
                if 'son' in obj_id_obj:
                    flattern_convertTo_tree_recursion(obj_id_obj['son'],node_list)
                obj_id_list[id_list_index] = obj_id_obj
    return obj_id_list


def difficulty(name):
    '''
    author: cst
    difficult类型状态
    :param name:
    :return:
    '''
    Literal = ('QuestionDifficultyKind','difficulty')  ## enum里面保存的name和question里面的数据名称不一样,对照元祖

    lookup = {"quesBank": name}
    botn = BOTNode.coll()
    lookup = Question.parsearg(request,lookup,botn)

    question = Question.coll()
    data = list(question.find(lookup))

    enum = Enum.coll()
    tag = enum.find_one({"name":Literal[0]}).get('literal')
    res = partitions(data,tag,Literal)
    resp = jsonify(res)
    return resp


def multi_dimension(name):
    lookup = {"quesBank": name}

    scope = json.loads(request.args.get('scope'))
    botn = BOTNode.coll()
    lookup = Question.parsearg(request,lookup,botn)

    Literal = get_literal(scope)

    question = Question.coll()
    data = list(question.find(lookup))
    resdata = {
        'count': len(data),
        'partition':[]
    }
    enum = Enum.coll()

    for Liter in Literal:
        tag = enum.find_one({"name": Liter[0]}).get('literal')
        res = partitions_dimension(data, tag, Liter)
        resdata['partition'].append(res)
    resp = jsonify(resdata)
    return resp


def material_kind(name):
    '''
    author: cst
    材料类型,语言类(英语)
    :param name:
    :return:
    '''
    Literal = ('QuestionMaterialKind','koMaterial')  ## enum里面保存的name和question里面的数据名称不一样,对照元祖
    lookup = {"quesBank": name}
    botn = BOTNode.coll()
    lookup = Question.parsearg(request, lookup, botn)
    # args = request.args
    # scope = args.get('scope')
    # if scope:  # scope 控制范围,如果没有这个参数默认查询name题库下所有
    #     lookup.update(json.loads(args.get('scope')))
    #     volumes = []
    #     if 'botn' in json.loads(scope):
    #         botnid = json.loads(scope).get('botn')
    #         recursion_structuring(botnid,volumes,BOTNode.coll())
    #         vid = [i.get('_id') for i in volumes if i.get('koLyro') == 'volume']
    #         lookup.update({"$or": [{"volume": {"$in": vid}}]})
    #         lookup.pop('botn')
    if lookup.get("volume"):
        lookup["volume"] = ObjectId(lookup.get("volume"))
    question = Question.coll()
    data = list(question.find(lookup))

    enum = Enum.coll()
    tag = enum.find_one({"name":Literal[0]}).get('literal')
    res = partitions(data,tag,Literal)
    resp = jsonify(res)
    return resp


# def batch_question_summations(name):
#     '''
#     author: cst
#     批量统计某册或章节下面所有子章节所有的统计状态信息
#     :param name:
#     :return:
#     '''
#     lookup = {"quesBank":name}
#     discipline = ''
#     args = request.args
#
#     if args.get('scope'):  # scope 控制范围,如果没有这个参数默认查询name题库下所有
#         scope = json.loads(args.get('scope'))
#         lookup.update(scope)
#
#     sonern = args.get('sonern-of')
#     if sonern:
#         botn = BOTNode.coll()
#         bot = botn.find_one({'_id': ObjectId(sonern)}, {"name": 1, "title": 1, "koLyro": 1})
#         if bot:
#             Lyro = bot.get("koLyro")
#             type = {Lyro:sonern}
#     lookup.update(type)
#     if lookup.get('koDiscipline') == 'english':
#         discipline = 'english'
#
#     question = Question.coll()
#     data = list(question.find(lookup))
#     res = batch_summations(data,type,bot,discipline)
#     resp = jsonify(res)
#     return resp
#
#
# def question_summations(name):
#     '''
#     author: cst
#     统计某章下面的节所有的统计状态信息
#     :param name:
#     :return:
#     '''
#     lookup = {"quesBank":name}
#     args = request.args
#     if args.get('scope'):  # scope 控制范围,如果没有这个参数默认查询name题库下所有
#         scope = json.loads(args.get('scope'))
#         if 'botn' in scope:
#             botnId = scope.pop('botn')
#             botn = BOTNode.coll()
#             bot = botn.find_one({'_id':ObjectId(botnId)},{"name":1,"title":1,"koLyro":1})
#             if bot:
#                 Lyro = bot.get("koLyro")
#                 scope.update({Lyro:botnId})
#         lookup.update(scope)
#     question = Question.coll()
#     data = question.find(lookup)
#     res = summations(data,bot)
#     resp = jsonify(res)
#     return resp

def similar(name,id=None,limit=5):
    '''
    重题检测,指定id,查找和该题类似题，否则全库查找同科目的类似题目
    :param name:
    :return:
    '''
    '''重题算法'''
    col_question = Question.coll()
    data = list(col_question.find().limit(5))
    resp =jsonify(json.loads(my_dump(data)))
    return resp


def stats(name):
    lookup = {'quesBank':name}
    args = request.args
    discipline = args.get('discipline')
    role = args.get('role')
    start = args.get('from')
    to = args.get('to')
    alt = args.get('alt')
    question = Question.coll()

    data = Question.get_stat(question,lookup,discipline,role,start,to)
    if alt == 'csv':
        data = json_to_csv(json.loads(my_dump(data)))
        response = make_response(data)
        response.headers["Content-Type"] = "text/csv"
        response.headers["Content-Disposition"] = "attachment; filename=statistic.csv"
        return response
        pass # todo export csv file
    else:
        resp = jsonify(json.loads(my_dump(dict(_items=data))))
        return resp

def tag(name):
    data = request.json
    question = Question.coll()
    l = []
    for i in data:
        id = i.get('_id')
        taginfo = i.get('taginfo')
        if 'boknCat' in taginfo:
            taginfo['boknCat'] = ObjectId(taginfo.get('boknCat'))
        lookup = {'quesBank':name,'_id':ObjectId(id)}
        upinfo = question.update(lookup,{"$set":taginfo})
        l.append(dict(id=id,
                    status= 'ok' if upinfo.get('ok') else 'error')
                    )
    return jsonify(dict(_items=l))