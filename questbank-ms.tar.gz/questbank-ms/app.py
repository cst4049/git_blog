from eve import Eve
from hooks.req_addon import *
from hooks.crud_addon import *
from werkzeug.routing import BaseConverter
from flask_cors import CORS
from resources import token_resource
from resources import stat_status
from resources import signals
from resources import pre_req
from resources import move
from resources import users_resource
import os

class RegexConverter(BaseConverter):
    '''
    路由中增加支持正则表达式
    '''
    def __init__(self, map, *args):
        self.map = map
        self.regex = args[0]

from customize import MyValidator

app = Eve(
    ## 扩展schema的定义，可使用UUID
    validator=MyValidator,
)

CORS(app) # 使能全部跨域
app.config['CORS_HEADERS'] = 'Content-Type'

app.url_map.converters['regex'] = RegexConverter  # 增加正则表达式支持

app.on_pre_GET += pre_GET
app.on_pre_PATCH += pre_PATCH
app.on_pre_PUT += pre_PUT
app.on_pre_POST += pre_POST
app.on_pre_DELETE += pre_DELETE
app.on_post_GET += post_GET
app.on_post_PATCH += post_PATCH
app.on_post_PUT += post_PUT
app.on_post_POST += post_POST
app.on_post_DELETE += post_DELETE

app.on_fetched_resource += after_fetched
app.on_insert += before_insert
app.on_insert_question += before_insert_question
app.on_inserted += after_insert


# also can work like this
@app.route('/hello')
def hello_world():
    return 'Hello World!'

app.before_request(pre_req.delay) # 在所有请求前调用该函数
app.before_request(pre_req.record)


app.add_url_rule('/tokens','token',token_resource.check_token,
                 methods=['GET','POST']
                 )


app.add_url_rule("/<bok_type>-english-bok-nodes","english_bokn",stat_status.english_bokn_query,
                 methods=["GET"])


app.add_url_rule('/users/<user_id>/passwd','users',users_resource.change_passwd,
                 methods=['PATCH','GET']
                 )

app.add_url_rule('/bot-nodes/<id>/<suffix>','botn_son',stat_status.botn_son,methods=['GET'])
app.add_url_rule('/bok-nodes/<id>/<suffix>','bokn_son',stat_status.bokn_son,methods=['GET'])

# app.add_url_rule('/aa/<id>','aa',signals.aa,methods=['GET'])

app.add_url_rule('/quesbanks/<name>/questions/<id>/<regex("[\w]+"):signal>',
                 'signal',signals.signal,methods=['POST']
                 )

app.add_url_rule('/quesbanks/<name>/question-partitions/by-difficulty/',
                 'difficulty',stat_status.difficulty,
                 methods=['GET']
                 )

app.add_url_rule('/quesbanks/<name>/question-partitions/by-multi-dimension/',
                 'multi_dimension',stat_status.multi_dimension,
                 methods=['GET']
                 )

app.add_url_rule('/quesbanks/<name>/question-partitions/by-material-kind/',
                 'material_kind',stat_status.material_kind,
                 methods=['GET']
                 )

app.add_url_rule('/quesbanks/<name>/question-summations/batch-tagged-checked-all/',
                 'batch_question_summations',stat_status.batch_question_summations,
                 methods=['GET']
                 )
#app.add_url_rule('/quesbanks/<name>/question-summations/batch-tagged-checked-all/',
# 'batch_question_summations',
# stat_status.batch_question_summations,
# methods=['GET'])

app.add_url_rule('/quesbanks/<name>/question-summations/tagged-checked-all/',
                 'question_summations',stat_status.question_summations,
                 methods=['GET']
                 )
#app.add_url_rule('/quesbanks/<name>/question-summations/tagged-checked-all/',
# 'question_summations',stat_status.question_summations,
# methods=['GET']) old题目上挂有卷章信息

app.add_url_rule('/quesbanks/<name>/questions/<id>/similar',
                 'similar',stat_status.similar,
                 methods=['GET']
                 )

app.add_url_rule('/quesbanks/<name>/questions/similar',
                 'similar',stat_status.similar,
                 methods=['GET']
                 )

app.add_url_rule('/quesbanks/<name>/questions/tagging',
                 'tag',stat_status.tag,
                 methods=['PATCH']
                 )

app.add_url_rule('/quesbanks/<name>/bulk:questions/',
                 'move',
                 move.move,
                 methods=['PATCH']
                 )

app.add_url_rule('/quesbanks/<name>/job-stats/res-per-user-typed-tagged-checked',
                 'res-per-user',
                 stat_status.stats,
                 methods=['GET']
                 )


if __name__ == '__main__':
    port = os.environ.get('HTTP_PORT')
    app.run(debug=True,host='0.0.0.0',
            port = int(port) if
                    port else 5000)
