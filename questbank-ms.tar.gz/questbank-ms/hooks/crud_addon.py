from bson import ObjectId

def after_fetched(resource_name,response):
    pass


def before_insert(resource_name,items):
    pass


def before_insert_question(items):
    if len(items) == 1:
        item = items[0]
        if item.get('sonCount') and item.get('sonCount') > 1 :
            if item.get('comboFormat') == 'matching': # todo 信息匹配要自动打上标签
                if item.get('optionCount') == 7 and item.get('sonCount') == 6:
                    pass
                if item.get('optionCount') == 6 and item.get('sonCount') == 4:
                    pass
                if item.get('optionCount') == 5 and item.get('sonCount') == 4:
                    pass
            origin_id = ObjectId()
            son_question = item.pop('sonOfAttr')
            soncount = item.pop('sonCount')

            for k, v in son_question.items():
                if v:
                    son_extra = [dict({k: i, '_id': ObjectId(), 'dadquestion': origin_id}, **item) for i in v]
            son = [son['_id'] for son in son_extra]
            item.update(son=son)
            item.update(sonCount=soncount)
            item.update(sonOfAttr=son_question)
            for i in son_extra:
                items.append(i)


def after_insert(resource_name,items):
    pass