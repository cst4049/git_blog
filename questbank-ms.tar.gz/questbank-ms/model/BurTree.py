
class BurTree:
    pass

class BurTreeNode:
    pass