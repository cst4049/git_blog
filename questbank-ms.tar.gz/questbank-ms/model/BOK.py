from flask import current_app as app
from model.BurTree import BurTreeNode;


class BOKNode(BurTreeNode):


    @staticmethod
    def coll():
        col = app.data.driver.db['bokn']
        return col


    @staticmethod
    def dadHomlyro(id):
        pass


    @staticmethod
    def all_bokn(id):
        col_botn = app.data.driver.db['bokn']
        col_botn.find({"_id":id,"_deleted":False},{})

    @staticmethod
    def find_one_by_edition_name(name,edition):
        return BOKNode.coll().find_one({"name":name,"edition":edition})

    @staticmethod
    def find_by_edition_name(name,edition):
        return BOKNode.coll().find({"name":name,"edition":edition})
