from flask import current_app as app
from model.BurTree import BurTreeNode;


class BOTNode(BurTreeNode):


    @staticmethod
    def coll():
        col = app.data.driver.db['botn']
        return col


    @staticmethod
    def dadHomlyro(id):
        pass


    @staticmethod
    def all_botn(id):
        col_botn = app.data.driver.db['botn']
        col_botn.find({"_id":id,"_deleted":False},{})
