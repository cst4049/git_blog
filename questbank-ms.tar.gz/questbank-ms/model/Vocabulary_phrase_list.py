from flask import current_app as app
from model.BurTree import BurTreeNode;


class Vocabulary_phrase:


    @staticmethod
    def coll():
        col = app.data.driver.db['vocabulary_phrase']
        return col


    @staticmethod
    def dadHomlyro(id):
        pass


    @staticmethod
    def all_bokn(id):
        col_botn = app.data.driver.db['vocabulary_phrase']
        col_botn.find({"_id":id,"_deleted":False},{})

    @staticmethod
    def find_one_by_name(name):
        return Vocabulary_phrase.coll().find_one({"name":name})
